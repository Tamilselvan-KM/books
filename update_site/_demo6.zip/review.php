<?php 
include_once 'includes/connect.php';
include_once 'includes/new_header.php';
if (isset($_SESSION['name'])) {
	$name = $_SESSION['name'];
}else{
    $name = "error";
}
?>
<head>
    <link rel="stylesheet" href="css/author.css">
</head>
<header class="header">

    <div class="header-1">
        
        <a href="home.php" class="logo"> <i class="fas fa-book"></i> bookly </a>

`
        <div class="icons">
            <a  href="./includes/logout.php"><div id="logout-btn" class="fas fa-power-off"></div></a>
        </div>

    </div>
    <?php
        require_once 'includes/topnav.php'; 
    ?>

</header>

    <?php
        require_once 'includes/bottomnav.php'; 
    ?>
    <h1 class="text-center"  style="font-size:30px;">Our Book Reviews</h1>
        <section>
        <div class="container">
            <?php 
            $query_str = "SELECT * FROM movies";
            $result = $conn->query($query_str);
            while ($movie_row = $result->fetch_assoc()):
            $movie_id = $movie_row['movie_id'];
            $review_str = "SELECT * FROM reviews WHERE review_movie_id='$movie_id'";
            $review_result = $conn->query($review_str);
            $review_row = $review_result->fetch_assoc();
            if ($review_row) {
            ?>
          <div class="small-container">
            <div class="row">
              <div class="col-4 lt">
                <h3 style="font-size:25px;color:#27AE60">
                    <a href="./includes/bookdetails.php?id=<?= $movie_row['movie_id'] ?>"><?= $movie_row['movie_name'] ?>
                    </a>
                </h3>
                <?php
                $review_result = $conn->query($review_str);
                while ($review_row = $review_result->fetch_assoc()) :
                ?>
                <h4 style="font-size:20px">
                    Rating: <span class="<?php
                                    if ($review_row['review_rating'] >= 4 ){
                                        echo 'text-success';
                                    } elseif ( $review_row['review_rating'] < 2 ) {
                                        echo 'text-danger';
                                    }
                                    ?>"> <?=$review_row['review_rating'] ?></span>
                </h4>
                <div class="info">
                  <p style="font-size:18px"><?= $review_row['review_content'] ?>
                  </p>
                  <hr style="width:20px">
                  <?php endwhile ?>
                </div>
              </div>
            </div>
          </div>
          <?php
        } endwhile?>
        </div>
    </section>
    <script src="./js/home.js"></script>
    <script src="./js/url.js"></script>
    <?php 
        include_once 'includes/new_footer.php';
    ?>
</body>