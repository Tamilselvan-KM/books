<?php 
include_once 'includes/connect.php';
include_once 'includes/new_header.php';
include_once 'includes/reviewcss.php';
if (isset($_SESSION['name'])) {
	$name = $_SESSION['name'];
}else{
    $name = "error";
}

//select statement
$query_str = "SELECT * FROM movies";

//execut the query
$result = $conn->query($query_str);

//Handle selection errors
if (!$result) {
	$errno = $conn->errno;
	$errmsg = $conn->error;
	echo "Selection failed with: ($errno) $errmsg<br/>\n";
	$conn->close();
	exit;
}
else{
?>
<head>
    <link rel="stylesheet" href="css/author.css">
</head>
<header class="header">

    <div class="header-1">
        
        <a href="home.php" class="logo"> <i class="fas fa-book"></i> bookly </a>


        <div class="icons">
            <a  href="./includes/logout.php"><div id="logout-btn" class="fas fa-power-off"></div></a>
        </div>

    </div>
    <?php
        require_once 'includes/topnav.php'; 
    ?>

</header>
    <?php
        require_once 'includes/bottomnav.php'; 
    ?>

    <h1 class="text-center">Welcome <?php echo $name ?></h1>
    <h1 class="text-center">Books</h1>
    <div class="container">
        <?php
			$i = 0;
			while ( $result_row = $result->fetch_assoc() ) :
				$i++;
				if ($i == 1) :
		?>
        <div class="row" style="justify-content:center;">
            <?php endif; ?>

            <div class="col-lg-4 col-md-4" style="margin:2%;">
                <div>
                    <a href="./includes/bookdetails.php?id=<?php echo $result_row['movie_id']; ?>">
                        <img src="<?php echo $result_row['movie_img'] ?>" class="img-fluid" style="width:100%;" />
                    </a>
                </div>
                <div class="content text-center">
                    <div class="fs-2 mb-4">
                        <?php
							echo "<a style='font-size:20px;' href='./includes/bookdetails.php?id=" . $result_row['movie_id'] . "'>", $result_row['movie_name'], "</a>";
						?>
                    </div>
                </div>
            </div>
            <?php if ($i == 3) : ?>
        </div>
        <?php $i=0; endif; endwhile; ?>
    </div>
        <script src="./js/url.js"></script>
    <?php include_once 'includes/new_footer.php';
    }
    ?>
