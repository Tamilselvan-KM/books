let menu = document.getElementById('menu-btn');
let close=document.getElementById('close-btn');
let items = document.querySelector('.menu-items');

menu.addEventListener('click', (e)=>{
    items.classList.add('active');
    close.style.display = "inline-block";
    menu.style.display = "none";
});
close.addEventListener('click', (e)=>{
    items.classList.remove('active');
    menu.style.display = "inline-block";
    close.style.display = "none";
});

