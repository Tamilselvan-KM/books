function indexAlert(msg){
    alert(`To see ${msg} please Login or Register first`);
}
