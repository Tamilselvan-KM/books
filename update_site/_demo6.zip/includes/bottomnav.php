<!-- bottom navbar  -->

<nav class="bottom-navbar">
    <a href="home.php" class="fas fa-home"></a>
    <a href="author.php" class="fas fa-user"></a>
    <a href="review.php" class="fas fa-star"></a>
    <a href="books.php" class="fas fa-book"></a>
</nav>