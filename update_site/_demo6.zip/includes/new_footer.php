<section class="footer">
    <div class="box-container">
        <div class="box">
            <h3>our locations</h3>
            <a>
                Let's Get In Touch!<br>
                M.Thiruvalluvar,42/21 , Pearl Block ,<br>Vigneshwara Apartments,Gandhi Road, TV KOIL ,<br>Trichy - 620005
            </a>
        </div>

        <div class="box">
            <!--<h3>quick links</h3>-->
            <!--<a href="./home.php"> <i class="fas fa-arrow-right"></i> home </a>-->
            <!--<a href="#"> <i class="fas fa-arrow-right"></i> reviews </a>-->
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +91 94426 31225 </a>
            <a href="mailto:thiruvalluvarmalaiyandi@gmail.com"> <i class="fas fa-envelope"></i>thiruvalluvarmalaiyandi@gmail.com</a>
        </div>
        
    </div>

    <div class="share">
        <a href="https://www.facebook.com/thiru.valluvar.142" class="fab fa-facebook-f" target="_blank"></a>
        <a href="https://twitter.com/MTHIRUVALLUVAR?t=Pz0yQhaSPcBtXnB5NsymdQ&s=08" class="fab fa-twitter" target="_blank"></a>
        <a href="https://www.instagram.com/thiruvalluvar_mtv/?utm_medium=copy_link" class="fab fa-instagram" target="_blank"></a>
        <a href="https://www.linkedin.com/in/thiruvalluvar-malaiyandi-5a392266" class="fab fa-linkedin" target="_blank"></a>
        <a href="https://www.youtube.com/channel/UCUWdQuTMjyTJOnaX7QK6aeA" class="fab fa-youtube" target="_blank"></a>
    </div>

    <div class="credit">Copyright&copy;<span>ComputiraSoftSolution</span>2022 | all rights reserved! </div>

</section>
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<script src="js/main.js"></script>
<script src="js/script.js"></script>
<script src="js/slider.js"></script>
</body>
</html>