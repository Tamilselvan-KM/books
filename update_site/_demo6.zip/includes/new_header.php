<?php
    session_start();
    //number of items in the shopping cart
    $count=0;

    //retrieve the cart content
    if ( isset ( $_SESSION['cart'] ) ){
        $cart = $_SESSION['cart'];

        if  ( $cart ) {
            $items = explode(',', $cart);
            $count = count($items);
        }
    }
    $role = 0;
    if (isset($_SESSION['role'])){
        $role = $_SESSION['role'];
    }
    if (isset($_SESSION['id'])) {
        $session_id = $_SESSION['id'];
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pudhiyapaarvaimathiruvalluvar</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>