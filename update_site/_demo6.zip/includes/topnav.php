    <div class="header-2">
        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="author.php">about us</a>
            <a href="review.php">reviews</a>
            <a href="books.php">books</a>
        </nav>
    </div>