    <div class="header-2">
        <nav class="navbar">
            <a href="./content.php">Add Content</a>
            <a href="includes/contentView.php">View Content</a>>
        </nav>
    </div>