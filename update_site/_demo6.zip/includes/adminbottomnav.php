<nav class="bottom-navbar">
            
            <a href="./content.php">Add Content</a>
            <a href="includes/contentView.php">View Content</a>>
</nav>