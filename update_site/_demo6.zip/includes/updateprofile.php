<?php
include_once ('connect.php');
include_once 'header.php';

//retrieve user id
$user_id = $session_id;
// echo $user_id;
?>

<head>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/button.css">

</head>

<body>
    <?php
//define the select statement
$query_str = "SELECT * FROM users WHERE user_id=" . $user_id;
$review_str = "select review_content, review_id, review_rating, movie_name, movie_id from reviews join movies on reviews.review_movie_id=movies.movie_id where reviews.review_user_id=" . $user_id;

//execute the query
$result = $conn->query($query_str);
$review_result = $conn->query($review_str);

//retrieve the results
$result_row = $result->fetch_assoc();



//Handle selection errors
if (!$result) {
	$errno = $conn->errno;
	$errmsg = $conn->error;
	echo "Selection failed with: ($errno) $errmsg<br/>\n";
	$conn->close();
	exit;
}        else{
?>
    <div class="container">
        <h1 class="text-center">Update Profile</h1>
        <div class="row">
            <div class="col-lg-6 col-md-6 m-auto py-5">
                <form action="update.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $result_row['user_id']; ?>" />
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Username</label>
                        <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Username"
                            name="user_name" value="<?php echo $result_row['user_name']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Name</label>
                        <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Name"
                            name="user_full_name" value="<?php echo $result_row['user_full_name']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Email</label>
                        <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Email"
                            name="user_email" value="<?php echo $result_row['user_email']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Password</label>
                        <input type="password" class="form-control" id="exampleFormControlInput1" placeholder="Password"
                            name="user_password" value="<?php echo $result_row['user_password']; ?>" required>
                    </div>
                    <div class="d-grid gap-2 col-6 mx-auto mt-3">
                        <button class="btn btn-outline-success me-2" type="submit" name="updbtn">Update</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <!-- <div class="col-lg-6 col-md-6 m-auto py-2"> -->
            <h1 class="text-center">Your Reviews</h1>
            <?php
					while ($review_row = $review_result->fetch_assoc()) { 
            ?>
            <div class="col-lg-6 col-md-6 m-auto py-2">
                <h3>
                    <a href="bookdetails.php?id=<?= $review_row['movie_id'] ?>"><?= $review_row['movie_name'] ?></a>
                </h3>
                <h4>Rating: <span class="<?php
									if ($review_row['review_rating'] >= 4) {
										echo 'text-success';
									} elseif ($review_row['review_rating'] < 2) {
										echo 'text-danger';
									}
									?>"> <?= $review_row['review_rating'] ?></span></h4>

                <p class="lead"><?= $review_row['review_content'] ?></p>
                <a class="btn btn-danger" href="deletereview.php?id=<?= $review_row['review_id'] ?>">DELETE</a>
            </div>
        </div>
        <?php
            }
        ?>
    </div>
    <?php 
    }
    ?>
</body>