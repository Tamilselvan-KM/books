<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pudhiyapaarvaimathiruvalluvar</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/styles.css">

</head>
<body>
<!-- login form  -->

<div class="reg-form-container">
    <form action="./includes/adminlogin.php" method="post">
        <h3>Admin Login</h3>
        <span>username</span>
        <input type="text" name="admin_user_name" class="box" placeholder="enter your username" id="" required>
        <span>password</span>
        <input type="password" name="admin_password" class="box" placeholder="enter your password" id="" required>
        <input type="submit" value="sign in" class="btn" name="adminlogbtn">
    </form>

</div>

</body>
</html>