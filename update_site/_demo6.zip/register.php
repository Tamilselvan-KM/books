<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pudhiyapaarvaimathiruvalluvar</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/styles.css">

</head>
<body>
<!-- login form  -->

<div class="reg-form-container">
    <form action="./includes/registeration.php" method="post">
        <h3>sign up</h3>
        <span>username</span>
        <input type="text" name="user_name" class="box" placeholder="enter your username" id="" required>
        <span>name</span>
        <input type="text" name="user_full_name" class="box" placeholder="enter your name" id="" required>
        <span>email</span>
        <input type="email" name="user_email" class="box" placeholder="enter your email" id="" required>
        <span>password</span>
        <input type="password" name="user_password" class="box" placeholder="enter your password" id="" required>
        <input type="submit" value="sign up" class="btn" name="regbtn">
        <p>have an account ? <a href="index.php">sign in</a></p>
    </form>

</div>

</body>
</html>