<?php
    require_once 'includes/new_header.php';
?>
<header class="header">

    <div class="header-1">

        <a href="home.php" class="logo"> <i class="fas fa-book"></i> bookly </a>

        <form action="" class="search-form">
            <input type="search" name="" placeholder="search here..." id="search-box">
            <label for="search-box" class="fas fa-search"></label>
        </form>

        <div class="icons">
            <div id="search-btn" class="fas fa-search"></div>
            <a  href="./includes/fav.php"><div id="fav" class="fas fa-heart"></div></a>
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="close-btn" class="fas fa-times" style="display:none;"></div>
            <a  href="./includes/logout.php"><div id="logout-btn" class="fas fa-power-off"></div></a>
        </div>
    </div>
    <?php
        require_once 'includes/topnav.php';
    ?>

</header>
<?php
    require_once 'includes/bottomnav.php';
?>

<!-- login form  -->

<div class="login-form-container">
    <div id="close-login-btn" class="fas fa-times"></div>
</div>


<section class="home" id="home">

    <div class="row">

        <div class="content">
        </div>

        <div class="menu-items">
            <a href="author.php" class="menu-link">About Author</a>
            <a href="events.php" class="menu-link">Events</a>
            <a href="blog.php" class="menu-link">Blog</a>
            <a href="essay.php" class="menu-link">Essay</a>
            <a href="article.php" class="menu-link">Articles</a>
            <a href="poetry.php" class="menu-link">Potery</a>
            <a href="conentviewuser.php" class="menu-link">Daily Potery</a>
        </div>
        <!--<div class="swiper books-slider">-->
        <!--    <div class="swiper-wrapper">-->
        <!--        <a href="author.php" class="swiper-slide categories">-->
        <!--            <p>About Author</p>-->
        <!--            <img src="./images/author.png" alt="" width="50px" height="50px">-->
        <!--        </a>-->
        <!--        <a href="events.php" class="swiper-slide categories">-->
        <!--            <p>Events</p>-->
        <!--            <img src="./images/event.png" alt="" width="50px" height="50px">-->
        <!--        </a>-->
        <!--        <a href="blog.php" class="swiper-slide categories">-->
        <!--            <p>Blog</p>-->
        <!--            <img src="./images/blogLink.png" alt="" width="50px" height="50px">-->
        <!--        </a>-->
        <!--        <a href="essay.php" class="swiper-slide categories">-->
        <!--            <p>Essay</p>-->
        <!--            <img src="./images/essayLink.jpg" alt="" width="50px" height="50px">-->
        <!--        </a>-->
        <!--        <a href="article.php" class="swiper-slide categories">-->
        <!--            <p>Articles</p>-->
        <!--            <img src="./images/articleLink.png" alt="" width="50px" height="50px">-->
        <!--        </a>-->
        <!--        <a href="poetry.php" class="swiper-slide categories">-->
        <!--            <p>Potery</p>-->
        <!--            <img src="./images/poteryLink.png" alt="" width="50px" height="50px">-->
        <!--        </a>-->
        <!--        <a href="conentviewuser.php" class="swiper-slide categories">-->
        <!--            <p>Daily Potery</p>-->
        <!--            <img src="./images/dailyPotery.png" alt="" width="50px" height="50px">-->
        <!--        </a>-->
        <!--    </div>-->
        <!--    <img src="images/stand.png" class="stand" alt="">-->
        <!--</div>-->

    </div>

</section>



<section class="featured" id="featured">

    <h1 class="heading"> <span>Photo Gallery</span>  </h1>

    <div class="swiper featured-slider">

        <div class="swiper-wrapper">

            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p1.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p2.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p3.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p4.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p5.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p6.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p7.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p8.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p9.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p10.jpeg" alt="">
                </div>
            </div>

        </div>

        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>

    </div>

</section>
<script src="./js/home.js"></script>
<?php
    require_once 'includes/new_footer.php';
?>