<?php
    require_once 'includes/new_header.php';
?>
<header class="header">

    <div class="header-1">

        <a href="index.php" class="logo"> <i class="fas fa-book"></i> bookly </a>

        <form action="" class="search-form">
            <input type="search" name="" placeholder="search here..." id="search-box">
            <label for="search-box" class="fas fa-search"></label>
        </form>

        <div class="icons">
            <div id="search-btn" class="fas fa-search"></div>
            <div id="login-btn" class="fas fa-user"></div>
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="close-btn" class="fas fa-times" style="display:none;"></div>
        </div>

    </div>

    <div class="header-2">
        <!--<nav class="navbar">-->
        <!--    <a href="">home</a>-->
        <!--    <a href="">about us</a>-->
        <!--    <a href="">reviews</a>-->
        <!--    <a href="">books</a>-->
        <!--</nav>-->
    </div>
</header>


<!-- login form  -->

<div class="login-form-container">
    <div id="close-login-btn" class="fas fa-times"></div>
    <form action="./includes/login.php" method="post">
        <h3>sign in</h3>
        <span>username</span>
        <input type="text" name="user_name" class="box" placeholder="enter your email" id="">
        <span>password</span>
        <input type="password" name="user_password" class="box" placeholder="enter your password" id="">
        <input type="submit" value="sign in" class="btn" name="logbtn">
        <p>don't have an account ? <a href="register.php">create one</a></p>
    </form>
</div>


<section class="home" id="home">

    <div class="row">

        <div class="content">
        </div>
        <div class="menu-items">
            <a href="" class="menu-link" onclick="indexAlert('Author Info')">About Author</a>
            <a href="" class="menu-link" onclick="indexAlert('Events')">Events</a>
            <a href="" class="menu-link" onclick="indexAlert('Blog')">Blog</a>
            <a href="" class="menu-link" onclick="indexAlert('Essay')">Essay</a>
            <a href="" class="menu-link" onclick="indexAlert('Articles')">Articles</a>
            <a href="" class="menu-link" onclick="indexAlert('Potery')">Potery</a>
            <a href="adminform.php" class="menu-link">Daily Potery</a>
        </div>
    </div>

</section>



<section class="featured" id="featured">

    <h1 class="heading"> <span>Photo Gallery</span> </h1>

    <div class="swiper featured-slider">

        <div class="swiper-wrapper">

            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p1.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p2.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p3.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p4.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p5.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p6.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p7.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p8.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p9.jpeg" alt="">
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="image">
                    <img src="images/p10.jpeg" alt="">
                </div>
            </div>

        </div>

        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>

    </div>

</section>

<!-- loader  -->

<div class="loader-container">
    <img src="images/loader-img.gif" alt="">
</div>
<script src="./js/home.js"></script>

<?php
    require_once 'includes/new_footer.php';
?>